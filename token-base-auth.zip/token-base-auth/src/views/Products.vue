<template>
  <div class="products">
    <h1>This is an products {{ parent }} - {{ name }}</h1>
  </div>
</template>

<script>
export default {
  props: { parent: String, name: String }
};
</script>
