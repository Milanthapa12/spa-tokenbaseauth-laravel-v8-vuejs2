<template>
  <div class="home">
    <Slider />
    <Featured />
  </div>
</template>

<script>
// @ is an alias to /src
import Slider from "@/components/Slider.vue";
import Featured from "@/components/Featured.vue";
export default {
  name: "Home",
  components: {
    Slider,
    Featured
  }
};
</script>
<style scoped>
.full-banner {
  padding: 25px;
}
</style>
