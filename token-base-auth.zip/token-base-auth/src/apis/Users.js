import Config from "./Config.js";

export default {
  register(form) {
    return Config().post("/register", form);
  },

  login(form) {
    return Config().post("/login", form);
  },

  logout() {
    return Config().post("/logout");
  },

  auth() {
    return Config().get("/user");
  }
};
