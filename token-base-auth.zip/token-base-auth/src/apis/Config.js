import axios from "axios";

let BaseConfig = axios.create({
  baseURL: "http://localhost:8000/api"
});

let Config = function() {
  let token = localStorage.getItem("token");
  if (token) {
    BaseConfig.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  }
  return BaseConfig;
};
export default Config;
