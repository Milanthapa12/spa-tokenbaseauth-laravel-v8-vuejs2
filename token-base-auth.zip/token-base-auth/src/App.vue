<template>
  <div id="app">
    <Navigation />
    <router-view />
    <Login />
    <Forgot />
    <Footer />
    <Register />
    <!-- <Message /> -->
  </div>
</template>
<script>
import Navigation from "./components/navbarComponent.vue";
import Footer from "./components/Footer.vue";
import Login from "@/components/Login.vue";
import Register from "@/components/Register.vue";
import Forgot from "@/components/Forgot.vue";
// import Message from "@/components/Message.vue";
export default {
  name: "App",
  components: {
    Navigation,
    Login,
    Forgot,
    Register,
    Footer
    // Message
  }
};
</script>
