<template>
  <div>
    <modal
      name="modal-register"
      @before-open="beforeOpen"
      :adaptive="true"
      :clickToClose="false"
      :height="464"
      :width="800"
    >
      <button type="button" class="close" @click="close">
        &times;
      </button>
      <div class="authenticate-container">
        <div class="bg-register">
          <img
            src="../assets/media-files/icons/young-girl.svg"
            alt="register"
          />
        </div>
        <div class="register">
          <p>Register</p>
          <div class="alert alert-success" v-if="message">{{ message }}</div>
          <div class="form-group text-center">
            <input
              type="text"
              name="name"
              placeholder="YOUR NAME..."
              class="form-control "
              @keydown.shift.tab.prevent
              v-model="form.name"
              autofocus
              :class="{ 'is-invalid': errors.name }"
            />
            <span v-if="errors.name" class="invalid-feedback">
              {{ errors.name[0] }}
            </span>
          </div>
          <div class="form-group text-center">
            <input
              type="email"
              name="email"
              placeholder="EMAIL..."
              class="form-control"
              @keydown.shift.tab.prevent
              v-model="form.email"
              :class="{ 'is-invalid': errors.email }"
            />
            <span v-if="errors.email" class="invalid-feedback">
              {{ errors.email[0] }}
            </span>
          </div>
          <div class="form-group">
            <input
              type="password"
              name="password"
              placeholder="PASSWORD..."
              class="form-control"
              v-model="form.password"
              :class="{ 'is-invalid': errors.password }"
            />
            <span v-if="errors.password" class="invalid-feedback">
              {{ errors.password[0] }}
            </span>
          </div>
          <div class="form-group">
            <input
              type="password"
              name="password_confirmation"
              placeholder="RETYPE PASSWORD..."
              class="form-control"
              v-model="form.password_confirmation"
              :class="{ 'is-invalid': errors.password_confirmation }"
            />
            <span v-if="errors.password_confirmation" class="invalid-feedback">
              {{ errors.password_confirmation[0] }}
            </span>
          </div>
          <div class="w-100 register-submit">
            <button
              type="submit"
              class="btn btn-primary w-100"
              @click.prevent="Register"
              :disabled="isActive"
            >
              {{ isActive ? "WAIT..." : "REGISTER" }}
            </button>
          </div>
          <div class="forget-ac-or-register">
            <div>
              <p>
                Already have an account?
                <a href="/#" @click="showLogin">Login</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </modal>
  </div>
</template>
<style scoped>
button.close {
  position: absolute;
  top: 4px;
  right: 8px;
  font-size: 30px;
}
.form-group {
  margin-bottom: 0.65em;
}
input[type="text"],
input[type="email"],
input[type="password"],
button {
  box-shadow: none;
  border-radius: 0px;
}
input[type="text"]::placeholder,
input[type="email"]::placeholder,
input[type="password"]::placeholder {
  /* Chrome, Firefox, Opera, Safari 10.1+ */
  font-size: 11px;
  font-weight: 600;
  color: #000;
  opacity: 0.6; /* Firefox */
}
.register p {
  text-align: left;
  font-size: 24px;
  /*padding-top: 40px;*/
}
.register input {
  margin: 5px 0px;
}
.register-submit input[type="submit"] {
  border-radius: 0px;
  font-size: 14px;
  font-weight: 600;
}
span.invalid-feedback {
  text-align: left;
}
.register-submit input[type="submit"]:focus {
  box-shadow: none;
}
.forget-ac-or-register {
  display: block;
  padding-top: 12px;
}
.forget-ac-or-register div p {
  font-size: 14px;
  padding: 0px;
  margin: 0px;
}
.forget-ac-or-register div p a {
  font-style: italic;
  color: #0079d3;
}
</style>
<script>
import User from "../apis/Users.js";
export default {
  name: "Login",
  data() {
    return {
      form: {
        name: "",
        email: "",
        password: "",
        password_confirmation: ""
      },
      errors: [],
      isActive: false,
      message: ""
    };
  },
  methods: {
    beforeOpen() {
      console.log("opening");
    },
    close() {
      this.$modal.hide("modal-register");
    },
    show() {
      this.$modal.show("modal-register");
    },
    showLogin() {
      this.$modal.hide("modal-register");
      this.$modal.show("modal-login");
    },
    Register() {
      this.isActive = true;

      // Csrf.getCookie().then(() => {
      User.register(this.form)
        .then(response => {
          if (response.status === 201) {
            this.message = response.data.message;
          }
          this.form.name = "";
          this.form.email = "";
          this.form.password = "";
          this.form.password_confirmation = "";
          this.errors = [];
          this.isActive = false;
          // this.$modal.show("modal-message");
          // this.$modal.hide("modal-register");
        })
        .catch(error => {
          if (error.response.status === 422) {
            this.errors = error.response.data.errors;
            this.isActive = false;
          }
        });
      // });
    }
  }
};
</script>
