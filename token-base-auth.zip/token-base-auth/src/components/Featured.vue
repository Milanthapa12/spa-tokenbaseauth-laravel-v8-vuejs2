<template>
  <div>
    <div class="product_section_container">
      <div class="product_section_title">
        <p>Featured Products</p>
      </div>
      <div class="product-container">
        <div class="products">
          <div class="product-box">
            <a href="/#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
              <div class="shop">
                <a href="#">Quick Shop</a>
              </div>
            </a>
            <div class="wishlist">
              <a href="/#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>

        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>

        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
        <div class="products">
          <div class="product-box">
            <a href="#">
              <div class="product-img">
                <img
                  src="../assets/media-files/products/p-1.jpeg"
                  class="img-fluid"
                  alt=""
                />
              </div>
            </a>
            <div class="wishlist">
              <a href="#" @click.prevent="wishlist"
                ><i class="fa fa-heart"></i
              ></a>
            </div>
            <div class="product-details">
              <div class="product-title">
                Green lehenga
              </div>
              <div class="product-price">
                Rs. 2000
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Featured",
  data() {
    return {
      isLoggedIn: false
    };
  },
  methods: {
    wishlist() {
      this.isLoggedIn = !!localStorage.getItem("auth");
      if (!this.isLoggedIn) {
        this.$modal.show("modal-login");
      }
    }
  }
};
</script>
